---
description: Executa o módulo de framing do caso
agent: collector-gpt
model: openai/gpt-5-mini
---

Siga estritamente a spec em @specs/02-case-framing.md.

Use como entrada o arquivo:
@cases/test-01/intake.json

Regras obrigatórias:
- Responder apenas em JSON válido
- Não gerar texto fora do JSON
- Separar fatos, hipóteses e lacunas
- Se faltar input, retornar erro estruturado
