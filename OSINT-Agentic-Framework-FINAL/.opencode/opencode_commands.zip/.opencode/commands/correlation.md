---
description: Correlação e anomalias
agent: collector-gpt
model: openai/gpt-5-mini
---

Siga a spec @specs/10-correlation-anomalies.md.

Use:
@cases/test-01/runs/

Saída: JSON válido
