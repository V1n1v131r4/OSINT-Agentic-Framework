---
description: Lições aprendidas
agent: reviewer
model: anthropic/claude-sonnet-4-5
---

Analise o caso completo:

@cases/test-01/

Produza:

- erros
- padrões
- melhorias de spec
- heurísticas reutilizáveis
