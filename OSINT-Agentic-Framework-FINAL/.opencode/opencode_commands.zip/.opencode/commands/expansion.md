---
description: Expansão da superfície OSINT
agent: collector-gpt
model: openai/gpt-5-mini
---

Siga a spec @specs/03-surface-expansion.md.

Use como base:
@cases/test-01/runs/02-framing-gpt.json

Saída: JSON válido
