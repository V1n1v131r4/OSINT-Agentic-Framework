---
description: Relatório final
agent: collector-gpt
model: openai/gpt-5-mini
---

Siga a spec @specs/11-reporting.md.

Use:
@cases/test-01/runs/10-correlation-gpt.json

Saída: JSON estruturado
